You should place the file called preclear_bjp.sh to the root of your flash drive.

If you are running a 32 bit version of unRAID, copy the file called "readvz" (not in the x64 directory) to the root of your flash drive.

If you are running a 64 bit version of unRAID, copy the "readvz" from the x64 directory of the zip file to the root of your flash drive.

I suggest running your preclears in "screen", but you can run from the console or however you like.

I also suggest using myMain to monitor the preclears. At the end it gives a nice summary of the times for each step.

You need to add the "-f" parameter (new to this version) to your preclear to use the new fast post-read. You can omit the "-f" to use the original method.

So to preclear a disk with the fast post-read, use this command:

e.g., /boot/preclear_bjp.sh -f -A /dev/sdz

Please do not distribute.